
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


def trades():
        
    # define column names
    col_names = ['Time','Symbol','Shares','Price']

    # import file. no header as first row has data. set column names 
    df = pd.read_csv('Path where the CSV file is stored/input.csv', names=col_names, header = None) 
    
    # time gap in mircoseconds between first and last trade 
    max_gap = df.groupby('Symbol').apply(lambda x: (x['Time'].max() - x['Time'].min()))
    
    # total volume traded per symbol 
    tot_volume = df.groupby(['Symbol']).apply(lambda x: x['Shares'].sum())
    
    # weighted average price per symbol 
    weighted_average_price = df.groupby('Symbol').apply(lambda x: int((x['Shares'] * x['Price']).sum() / x['Shares'].sum()))
    
    # max executed price per symbol
    max_trade_price = df.groupby('Symbol').apply(lambda x: x['Price'].max())
        
    # concatenate 
    output = pd.concat([max_gap, tot_volume, weighted_average_price, max_trade_price], axis=1)
    
    # transform output back to csv
    output.to_csv(r'Path where the CSV file will be stored/output.csv', header=False, index=False)
    
    return output

